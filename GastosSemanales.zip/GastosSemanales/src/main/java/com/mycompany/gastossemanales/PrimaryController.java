package com.mycompany.gastossemanales;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML private TextField txtAlimentacion;
    @FXML private TextField txtRefrigerios;
    @FXML private TextField txtTransporte;
    @FXML private TextField txtTelefonia;
    @FXML private TextField txtOtros;
    
    @FXML private TextField txtTotalSemanal;
    @FXML private TextField txtGastoMasAlto;

    @FXML
    void calcularEstadisticas(ActionEvent event) {
        try {
            double alimentacion = Double.parseDouble(txtAlimentacion.getText());
            double refrigerios = Double.parseDouble(txtRefrigerios.getText());
            double transporte = Double.parseDouble(txtTransporte.getText());
            double telefonia = Double.parseDouble(txtTelefonia.getText());
            double otros = Double.parseDouble(txtOtros.getText());

            double total = alimentacion + refrigerios + transporte + telefonia + otros;
            txtTotalSemanal.setText(String.valueOf(total));

            // Encontrar el gasto más alto
            double max = alimentacion;
            String categoria = "Alimentación";

            if (refrigerios > max) { max = refrigerios; categoria = "Refrigerios"; }
            if (transporte > max) { max = transporte; categoria = "Transporte"; }
            if (telefonia > max) { max = telefonia; categoria = "Telefonía"; }
            if (otros > max) { max = otros; categoria = "Otros"; }

            txtGastoMasAlto.setText(categoria);

        } catch (NumberFormatException e) {
            txtTotalSemanal.setText("Error en datos");
            txtGastoMasAlto.setText("Verifique campos");
        }
    }

    @FXML
    void limpiarCampos(ActionEvent event) {
        txtAlimentacion.setText("");
        txtRefrigerios.setText("");
        txtTransporte.setText("");
        txtTelefonia.setText("");
        txtOtros.setText("");
        txtTotalSemanal.setText("");
        txtGastoMasAlto.setText("");
    }
}