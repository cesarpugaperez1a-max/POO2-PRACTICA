package com.mycompany.personaalumnoprofesor;

public class App {
    public static void main(String[] args) {
        Alumno a = new Alumno();
        Profesor p = new Profesor(10008200);
        
        System.out.println("Se crea Alumno...");
        System.out.println(a.toString());
        System.out.println(p.toString());
    }
}