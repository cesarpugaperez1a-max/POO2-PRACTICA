module com.mycompany.personaalumnoprofesor {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.personaalumnoprofesor to javafx.fxml;
    exports com.mycompany.personaalumnoprofesor;
}
