package com.mycompany.edad;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML
    private TextField txtFecha;

    @FXML
    private Label lblResultado;

    @FXML
    void calcularEdad(ActionEvent event) {
        try {
            String textoFecha = txtFecha.getText();
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fechaNacimiento = LocalDate.parse(textoFecha, formato);
            LocalDate fechaActual = LocalDate.now();

            Period periodo = Period.between(fechaNacimiento, fechaActual);
            int anios = periodo.getYears();
            int meses = periodo.getMonths();

            lblResultado.setText("Tiene " + anios + " años con " + meses + " meses");
        } catch (Exception e) {
            lblResultado.setText("Formato incorrecto (use dd/mm/aaaa)");
        }
    }

    @FXML
    void limpiarCampos(ActionEvent event) {
        txtFecha.setText("");
        lblResultado.setText("");
    }
}
