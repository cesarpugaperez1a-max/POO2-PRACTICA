package com.mycompany.conteo;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML
    private TextField txtClicks;

    @FXML
    private Button btnContar;

    @FXML
    private ProgressBar progressBar;

    @FXML
    private Button btnEsperar;

    private int contadorClicks = 0;

    @FXML
    void contarClic(ActionEvent event) {
        contadorClicks++;
        txtClicks.setText(String.valueOf(contadorClicks));
    }

    @FXML
    void iniciarEspera(ActionEvent event) {
        btnEsperar.setDisable(true); // Deshabilita el botón mientras carga
        progressBar.setProgress(0);

        // Hilo independiente para que la interfaz no se congele
        new Thread(() -> {
            try {
                for (int i = 1; i <= 100; i++) {
                    Thread.sleep(100); // 100ms * 100 = 10 segundos en total
                    final double avance = i / 100.0;
                    
                    // Actualiza la barra de progreso de manera segura en JavaFX
                    Platform.runLater(() -> progressBar.setProgress(avance));
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                // Vuelve a habilitar el botón cuando termine
                Platform.runLater(() -> btnEsperar.setDisable(false));
            }
        }).start();
    }
}