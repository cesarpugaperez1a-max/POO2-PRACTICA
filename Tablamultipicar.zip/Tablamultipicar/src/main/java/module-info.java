module com.mycompany.tablamultipicar {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.tablamultipicar to javafx.fxml;
    exports com.mycompany.tablamultipicar;
}
