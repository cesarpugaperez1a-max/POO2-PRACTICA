package com.mycompany.tablamultipicar;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML private TextField txtNumero;
    @FXML private TextArea txtAreaTabla;

    @FXML
    void calcularTabla(ActionEvent event) {
        try {
            int n = Integer.parseInt(txtNumero.getText());
            StringBuilder sb = new StringBuilder();
            
            for (int i = 1; i <= 10; i++) {
                sb.append(n).append(" x ").append(i).append(" = ").append(n * i).append("\n");
            }
            
            txtAreaTabla.setText(sb.toString());
        } catch (NumberFormatException e) {
            txtAreaTabla.setText("Ingrese un número entero válido.");
        }
    }

    @FXML
    void limpiarTabla(ActionEvent event) {
        txtNumero.setText("");
        txtAreaTabla.setText("");
    }
}
