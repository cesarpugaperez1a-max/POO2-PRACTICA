package com.mycompany.liebreytortuga;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

public class PrimaryController {

    @FXML private ProgressBar barraLiebre;
    @FXML private ProgressBar barraTortuga;
    @FXML private Label lblEstadoLiebre;
    @FXML private Label lblEstadoTortuga;
    @FXML private Button btnIniciar;

    @FXML
    void iniciarCarrera(ActionEvent event) {
        btnIniciar.setDisable(true);
        barraLiebre.setProgress(0);
        barraTortuga.setProgress(0);

        // Hilo de la Liebre
        new Thread(() -> {
            try {
                for (int i=1; i <=50; i++) {
                    Thread.sleep(80);
                    double p = i / 100.0;
                    Platform.runLater(() -> {
                        barraLiebre.setProgress(p);
                        lblEstadoLiebre.setText("La Liebre: Está corriendo");
                    });
                }
                Platform.runLater(() -> lblEstadoLiebre.setText("La Liebre: ¡Se durmió!"));
                Thread.sleep(3000); 

                for (int i = 51; i <= 100; i++) {
                    Thread.sleep(60);
                    double p = i / 100.0;
                    Platform.runLater(() -> {
                        barraLiebre.setProgress(p);
                        lblEstadoLiebre.setText("La Liebre: Despertó y corre");
                    });
                }
                Platform.runLater(() -> lblEstadoLiebre.setText("La Liebre: Llegó a la meta"));
            } catch (Exception e) {}
        }).start();

        new Thread(() -> {
            try {
                for (int i = 1; i <= 100; i++) {
                    Thread.sleep(120);
                    double p = i / 100.0;
                    Platform.runLater(() -> {
                        barraTortuga.setProgress(p);
                        lblEstadoTortuga.setText("La Tortuga: Va avanzando");
                    });
                }
                Platform.runLater(() -> {
                    lblEstadoTortuga.setText("La Tortuga: ¡Llegó a la meta!");
                    btnIniciar.setDisable(false); // Reactivar botón al terminar toda la carrera
                });
            } catch (Exception e) {}
        }).start();
    }
}