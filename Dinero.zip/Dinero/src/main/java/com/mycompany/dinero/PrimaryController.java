package com.mycompany.dinero;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML
    private TextField txtDinero;

    @FXML
    private TextArea txtAreaDesglose;

    @FXML
    void desglosarDinero(ActionEvent event) {
        try {
            int monto = Integer.parseInt(txtDinero.getText());
            int[] denominaciones = {500, 200, 100, 50, 20, 10, 5, 2, 1};
            StringBuilder resultado = new StringBuilder();

            for (int d : denominaciones) {
                int cantidad = monto / d;
                monto %= d;
                
                String tipo = (d >= 20) ? "Billetes de $" : "Monedas de $";
                resultado.append(tipo).append(d).append("\t\t").append(cantidad).append("\n");
            }

            txtAreaDesglose.setText(resultado.toString());
        } catch (NumberFormatException e) {
            txtAreaDesglose.setText("Por favor ingrese una cantidad válida.");
        }
    }

    @FXML
    void limpiarDinero(ActionEvent event) {
        txtDinero.setText("");
        txtAreaDesglose.setText("");
    }
}
