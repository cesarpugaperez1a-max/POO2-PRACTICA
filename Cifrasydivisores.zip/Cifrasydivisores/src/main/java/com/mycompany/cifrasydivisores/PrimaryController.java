package com.mycompany.cifrasydivisores;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML private TextField txtNumero;
    @FXML private TextField txtCantidadCifras;
    @FXML private TextField txtSumaImpares;
    @FXML private TextField txtSumaPares;
    @FXML private TextField txtSumaTotal;
    @FXML private TextField txtCifraMayor;
    @FXML private TextField txtCifraMenor;
    @FXML private ListView<String> listDivisores;

    @FXML
    void analizarNumero(ActionEvent event) {
        try {
            int n = Integer.parseInt(txtNumero.getText());
            int temp = Math.abs(n);
            
            int cantidad = 0, sumaPares = 0, sumaImpares = 0, sumaTotal = 0;
            int mayor = 0, menor = 9;

            if (temp == 0) {
                cantidad = 1;
                sumaTotal = 0;
                mayor = 0;
                menor = 0;
            } else {
                while (temp > 0) {
                    int digito = temp % 10;
                    cantidad++;
                    sumaTotal += digito;
                    if (digito % 2 == 0) {
                        sumaPares += digito;
                    } else {
                        sumaImpares += digito;
                    }
                    if (digito > mayor) mayor = digito;
                    if (digito < menor) menor = digito;
                    
                    temp /= 10;
                }
            }

            txtCantidadCifras.setText(String.valueOf(cantidad));
            txtSumaImpares.setText(String.valueOf(sumaImpares));
            txtSumaPares.setText(String.valueOf(sumaPares));
            txtSumaTotal.setText(String.valueOf(sumaTotal));
            txtCifraMayor.setText(String.valueOf(mayor));
            txtCifraMenor.setText(String.valueOf(menor));

            // Calcular divisores
            listDivisores.getItems().clear();
            for (int i = 1; i <= Math.abs(n); i++) {
                if (n % i == 0) {
                    listDivisores.getItems().add(String.valueOf(i));
                }
            }
        } catch (NumberFormatException e) {
            txtCantidadCifras.setText("Error");
        }
    }

    @FXML
    void limpiarCampos(ActionEvent event) {
        txtNumero.setText("");
        txtCantidadCifras.setText("");
        txtSumaImpares.setText("");
        txtSumaPares.setText("");
        txtSumaTotal.setText("");
        txtCifraMayor.setText("");
        txtCifraMenor.setText("");
        listDivisores.getItems().clear();
    }
}